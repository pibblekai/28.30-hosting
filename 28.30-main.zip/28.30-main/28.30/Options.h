inline int MaxTickRate = 30;
inline bool bIris = false;